UPDATE Train
SET isPetFriendly = "no"
WHERE lineColor = "yellow"

DELETE FROM Stop
WHERE stationNo = 44

DELETE FROM Ticket
WHERE expiryDate < (current_date() - INTERVAL 5 month);
