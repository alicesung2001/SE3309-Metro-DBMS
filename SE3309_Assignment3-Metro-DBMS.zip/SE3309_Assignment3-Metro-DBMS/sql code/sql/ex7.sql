CREATE VIEW StationInfo AS
SELECT  l.lineColor, s.stationName, streetNum, streetName
FROM Line l, Station s, Stop st
WHERE st.lineCol = "orange"
AND st.stationNo = s.stationNo

CREATE VIEW TrainInfo AS
SELECT t.trainNo, t.lineColor, t.isAccessible
FROM Train t, Stop st
WHERE t.lineColor = st.lineCol
AND t.isAccessible = 'yes'
GROUP BY trainNo

CREATE VIEW TimeInfo AS
SELECT lineCol, s.stationNo, stationName, streetNum, streetName, st.arrivalTime
FROM Stop st, Station s
WHERE st.stationNo = s.stationNo
AND st.arrivalTime <= time('9:00:00')
AND st.arrivalTime <= time('10:00:00')
