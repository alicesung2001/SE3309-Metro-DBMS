INSERT INTO Train(trainNo, lineColor) VALUES (1, "orange");

INSERT INTO Station VALUES (10, 'Station Sherbrooke', 4545, 'Larry Trail');

INSERT INTO Passenger values ('001002', default);
