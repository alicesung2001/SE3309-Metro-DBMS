SELECT passengerType, COUNT(*) AS count
FROM Passenger
GROUP BY passengerType;

SELECT trainNo
FROM Train t
WHERE EXISTS (SELECT *
		      FROM Stop s
		      WHERE t.lineColor= s.lineCol AND s.StationNo = 55)
          
SELECT passengerType, COUNT(*) AS count
FROM Passenger
WHERE passengerID IN (SELECT passengerId
				FROM Trip
				WHERE trainNo = 12) 
GROUP BY  passengerType

SELECT lineCol, COUNT(*) AS noOfStations
FROM Stop s, Station st
WHERE s.stationNo = st.stationNo
GROUP BY lineCol

SELECT purchasedBy, activationDate
FROM Ticket
WHERE activationDate >= DATE('2021-01-01')  AND activationDate <= DATE ('2021-02-01')

SELECT t.trainNo, COUNT(*) AS noOfTrips
FROM Trip t, Train tr
WHERE t.trainNo = tr.trainNo
GROUP BY t.trainNo

SELECT passengerType, COUNT(*) AS noOfTickets
FROM Ticket t, Passenger p
WHERE t.purchasedBy = p.passengerID
GROUP BY passengerType


